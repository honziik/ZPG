#pragma once
#include "Scene.h"
#include "Translate.cpp"
#include "Scale.cpp"
#include "Rotate.cpp"
#include "CompositTransform.cpp"
class SceneFactory
{
public:
	static Scene* createFirstScene();
	static Scene* createSecondScene();
	static Scene* createThirdScene();
	static Scene* createFourthScene();
};

